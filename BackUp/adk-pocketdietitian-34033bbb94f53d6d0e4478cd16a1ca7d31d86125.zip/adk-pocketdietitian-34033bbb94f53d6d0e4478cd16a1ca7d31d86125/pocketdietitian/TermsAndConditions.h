//
//  TermsAndConditions.h
//  pocketdietitian
//
//  Created by Andrej Kostresevic on 2/8/12.
//  Copyright (c) 2012 New Frontier Nomads. All rights reserved.
//

#import "BaseViewController.h"

@interface TermsAndConditions : BaseViewController

@end
