#import "Food.h"

@implementation Food

// Custom logic goes here.

@end
