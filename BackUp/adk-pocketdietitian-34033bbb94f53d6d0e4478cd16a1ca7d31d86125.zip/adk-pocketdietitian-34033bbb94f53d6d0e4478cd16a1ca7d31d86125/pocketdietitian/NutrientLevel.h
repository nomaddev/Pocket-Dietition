#import "_NutrientLevel.h"

@interface NutrientLevel : _NutrientLevel {}
// Custom logic goes here.
@end
