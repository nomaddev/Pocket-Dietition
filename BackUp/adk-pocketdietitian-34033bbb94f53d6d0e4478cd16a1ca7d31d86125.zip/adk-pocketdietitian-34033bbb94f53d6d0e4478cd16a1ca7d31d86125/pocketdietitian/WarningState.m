//
//  WarningState.m
//  pocketdietitian
//
//  Created by Andrej Kostresevic on 3/1/12.
//  Copyright (c) 2012 New Frontier Nomads. All rights reserved.
//

#import "WarningState.h"

@implementation WarningState

@synthesize violatedLimitType;
@synthesize warningSeverity;

@end
