#import "NutrientLevel.h"

@implementation NutrientLevel

// Custom logic goes here.

@end
