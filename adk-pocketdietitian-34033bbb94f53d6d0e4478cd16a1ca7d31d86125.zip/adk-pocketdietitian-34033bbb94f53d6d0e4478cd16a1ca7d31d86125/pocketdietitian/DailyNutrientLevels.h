#import "_DailyNutrientLevels.h"

@interface DailyNutrientLevels : _DailyNutrientLevels {}
// Custom logic goes here.
@end
