#import "_Nutrient.h"


@interface Nutrient : _Nutrient 
{
    
}

// Custom logic goes here.

+(NSString *) friendlyNameForNutrientNo: (NSString*) nutNo;
+(NSString *) friendlyTooMuchLanguageForNutrientNo: (NSString*) nutNo;

@end
