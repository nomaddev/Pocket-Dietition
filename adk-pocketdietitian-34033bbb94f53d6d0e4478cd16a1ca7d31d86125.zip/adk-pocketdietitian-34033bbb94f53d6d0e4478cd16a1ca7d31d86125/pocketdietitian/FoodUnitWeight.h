#import "_FoodUnitWeight.h"

@interface FoodUnitWeight : _FoodUnitWeight {}
// Custom logic goes here.

-(float) totalGramWeightForAmountConsumed:(NSNumber*) amountConsumed;
@end
