//
//  ReviewAndContinueView.h
//  pocketdietitian
//
//  Created by hardik on 4/3/12.
//  Copyright (c) 2012 New Frontier Nomads. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReviewAndContinueView : UIViewController
{
    
}
-(IBAction)btnClicked:(id)sender;

@end
