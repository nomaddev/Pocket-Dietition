#import "_FoodNutrientData.h"

@interface FoodNutrientData : _FoodNutrientData {}
// Custom logic goes here.

-(float) nutrientValueForGramAmount:(float) gramAmount;
@end
