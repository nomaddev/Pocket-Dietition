#import "FoodGroup.h"

@implementation FoodGroup

// Custom logic goes here.

@end
