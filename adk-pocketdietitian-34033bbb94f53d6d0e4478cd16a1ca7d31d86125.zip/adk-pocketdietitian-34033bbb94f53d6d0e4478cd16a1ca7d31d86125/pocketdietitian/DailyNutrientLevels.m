#import "DailyNutrientLevels.h"

@implementation DailyNutrientLevels

// Custom logic goes here.

@end
