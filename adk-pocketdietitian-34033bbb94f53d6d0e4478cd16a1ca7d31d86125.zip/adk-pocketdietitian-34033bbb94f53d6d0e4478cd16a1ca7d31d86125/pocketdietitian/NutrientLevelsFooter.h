//
//  NutrientLevelsFooter.h
//  pocketdietitian
//
//  Created by Rafael Santiago, Jr. on 3/2/12.
//  Copyright (c) 2012 New Frontier Nomads. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NutrientLevelsFooter : UIView
@property (unsafe_unretained, nonatomic) IBOutlet UIButton *moreButton;

@end
