#import "_Food.h"

@interface Food : _Food {}
// Custom logic goes here.
@end
