//
//  TermsAndConditionView.h
//  pocketdietitian
//
//  Created by hardik on 4/3/12.
//  Copyright (c) 2012 New Frontier Nomads. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsAndConditionView : UIViewController
{
    
}

-(IBAction)btnAcceptClicked;

@end
