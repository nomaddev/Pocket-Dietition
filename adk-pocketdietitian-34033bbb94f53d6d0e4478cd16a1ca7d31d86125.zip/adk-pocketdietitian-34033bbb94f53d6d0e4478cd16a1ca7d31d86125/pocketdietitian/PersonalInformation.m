//
//  PersonalInformation.m
//  pocketdietitian
//
//  Created by hardik on 4/3/12.
//  Copyright (c) 2012 New Frontier Nomads. All rights reserved.
//

#import "PersonalInformation.h"
#import "ReviewAndContinueView.h"

@implementation PersonalInformation
@synthesize arrGender,arrActivityLevel,scrollView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        // Custom initialization  
    }
    return self;
}

- (void)didReceiveMemoryWarning 
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
} 


#pragma mark - User Defined Functions

-(IBAction)backgroundTouched
{
    [txtAge resignFirstResponder];
    [txtHeightFoot resignFirstResponder];
    [txtHeightInch resignFirstResponder];
    [txtWeight resignFirstResponder];
}

-(IBAction)btnDropdownClicked:(id)sender
{
    
    arrGender = [[NSMutableArray alloc]init];
    arrActivityLevel = [[NSMutableArray alloc]init];
    
    UIButton *btn = (UIButton*)sender; 
    
    switch (btn.tag)
    {
        case 0: 
        {
//            arrGender = [[NSMutableArray alloc]initWithObjects:@"Male",@"Female", nil];
//            
//            tableGender.hidden = FALSE;
//            [tableGender reloadData];

            [btnMale setImage:[UIImage imageNamed:@"check_selected.png"] forState:UIControlStateNormal];
            [btnFemale setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
            
            NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
            [preferences setObject:@"YES" forKey:@"Male"];
            [preferences synchronize];
            
            NSUserDefaults *preferences1 = [NSUserDefaults standardUserDefaults];
            [preferences1 setObject:@"NO" forKey:@"Female"];
            [preferences1 synchronize];
            
            return;
        }
        case 1:
            
            arrActivityLevel = [[NSMutableArray alloc]initWithObjects:@"Little to no exercise",@"Light exercise (1–3 days per week)",@"Moderate exercise (3–5 days per week)",@"Heavy exercise (6–7 days per week)",@"Very heavy exercise (twice per day, extra heavy workouts)", nil];
            
            tableActivityLevel.hidden = FALSE;
            [tableActivityLevel reloadData];

            return;
            
        case 2:
        {
            NSLog(@"%@ %@ %@ %@ %@",txtHeightFoot.text,txtHeightInch.text,txtWeight.text,txtAge.text,txtActivityLevel.text);
            
            if ([txtHeightFoot.text isEqualToString:@""] || [txtHeightInch.text isEqualToString:@""] || [txtWeight.text isEqualToString:@""] || [txtAge.text isEqualToString:@""] || [txtActivityLevel.text isEqualToString:@""])
                
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Warning" message:@"All fields are mandatory" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
                
                [alert show];
                return;
            }
            else 
            {
                NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
                
                [preferences setObject:txtHeightFoot.text forKey:@"HeightFoot"];
                [preferences setObject:txtHeightInch.text forKey:@"HeightInch"];
                [preferences setObject:txtWeight.text forKey:@"Weight"];
                [preferences setObject:txtAge.text forKey:@"Age"];
                //[preferences setObject:txtGender.text forKey:@"Gender"];
                [preferences setObject:txtActivityLevel.text forKey:@"ActivityLevel"];
                
                [preferences synchronize];
                
                [self.navigationController pushViewController:[[ReviewAndContinueView alloc] init] animated:TRUE];
            }
           
        }  
            
        case 3:
        {
            [btnMale setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
            [btnFemale setImage:[UIImage imageNamed:@"check_selected.png"] forState:UIControlStateNormal];
            
            NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
            [preferences setObject:@"YES" forKey:@"Female"];
            [preferences synchronize];
            
            NSUserDefaults *preferences1 = [NSUserDefaults standardUserDefaults];
            [preferences1 setObject:@"NO" forKey:@"Male"];
            [preferences1 synchronize]; 
            return;
        }
    }
    
    
}

-(void)BackAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma Text Field Delegate Method

-(BOOL)textFieldShouldReturn:(UITextField*)textField
{
    [scrollView setContentOffset:svos animated:YES]; 
    [textField resignFirstResponder];
    return YES;
}


- (void)textFieldDidBeginEditing:(UITextField *)textField;
{
    
    textField.placeholder = @"";
    svos = scrollView.contentOffset;
    CGPoint pt;
    CGRect rc = [textField bounds];
    
    rc = [textField convertRect:rc toView:scrollView];
    pt = rc.origin;
    pt.x = 0;
    pt.y -= 160;
    
    [scrollView setContentOffset:pt animated:YES]; 
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [txtHeightFoot becomeFirstResponder];
    
    self.title = @"My Health Information";
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(BackAction)];
    
    self.navigationItem.leftBarButtonItem = backButton;
    [self.navigationController.navigationBar setTintColor:[UIColor colorWithRed:32.0/255.0 green:134.0/255.0 blue:148.0/255.0 alpha:1]];
    
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];

    
    txtHeightFoot.text = [preferences objectForKey:@"HeightFoot"];
    txtHeightInch.text = [preferences objectForKey:@"HeightInch"];
    txtWeight.text = [preferences objectForKey:@"Weight"];
    txtAge.text = [preferences objectForKey:@"Age"];
    //txtGender.text = [preferences objectForKey:@"Gender"];
    txtActivityLevel.text = [preferences objectForKey:@"ActivityLevel"];
    
    
    NSString *strMale = [preferences objectForKey:@"Male"];
    NSString *strFemale = [preferences objectForKey:@"Female"];
    
    if ([strMale isEqualToString:@"YES"])
    {
        [btnMale setImage:[UIImage imageNamed:@"check_selected.png"] forState:UIControlStateNormal];
        [btnMale setSelected:YES];
    }
    if ([strFemale isEqualToString:@"YES"])
    {
        [btnFemale setImage:[UIImage imageNamed:@"check_selected.png"] forState:UIControlStateNormal];
        [btnFemale setSelected:YES];
    }
    
    // Do any additional setup after loading the view from its nib.
} 

-(void)viewWillAppear:(BOOL)animated
{

    tableActivityLevel.hidden = TRUE;
    tableGender.hidden = TRUE;
    
    scrollView.contentSize = CGSizeMake(320,570);
    CGPoint topOffset = CGPointMake(0,0);
    [scrollView setContentOffset:topOffset animated:NO];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Textfield Delegate Methods

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string 
{
    if (textField.tag == 0 || textField.tag == 1) 
    {
        NSUInteger newLength = [textField.text length] + [string length] - range.length;
        return (newLength > 2) ? NO : YES;
    }
    else if (textField.tag == 2)
    {
        if ([textField.text integerValue] > 1000)
        {
            textField.text = @"";
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Warning" message:@"Weight must be less than 1000." delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
            [alert show];
            return NO;
            
        }
        return YES;
    }
    else
    {
        if ([textField.text integerValue] > 100)
        {
            textField.text = @"";
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Warning" message:@"Age must be less than 100." delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            
             [alert show];
            
            return NO;
        }
         return YES;
    }
}


#pragma mark - TableView Delegate Methods

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == tableGender)
    {
        return [arrGender count];
    }
    else
        return [arrActivityLevel count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == tableGender)
    {
        static NSString *CellIdentifier = @"Cell";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            
        }
        
        cell.textLabel.text = [arrGender objectAtIndex:indexPath.row];
        
        return cell;
    }
    else
    {
        static NSString *CellIdentifier = @"Cell";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            
        }
        
        cell.textLabel.text = [arrActivityLevel objectAtIndex:indexPath.row];
        [cell.textLabel setFont:[UIFont boldSystemFontOfSize:16]];
        cell.textLabel.numberOfLines = 3;
        cell.textLabel.lineBreakMode = UILineBreakModeWordWrap;
        
        cell.textLabel.textColor = [UIColor colorWithRed:19.0/255.0 green:96.0/255.0 blue:114.0/255.0 alpha:1];
        //cell.textLabel.shadowColor = [UIColor whiteColor];
        //cell.textLabel.shadowOffset = CGSizeMake(-1,0);

        
        tableView.separatorColor = [UIColor colorWithRed:32.0/255.0 green:134.0/255.0 blue:148.0/255.0 alpha:1];
        
        return cell;
    }
    
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == tableGender)
        return 30;
    else
        return 45;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == tableGender)
    {
        //txtGender.text = [arrGender objectAtIndex:indexPath.row];
        //tableGender.hidden = TRUE;
    }
    else
    {
        txtActivityLevel.text = [arrActivityLevel objectAtIndex:indexPath.row];
        tableActivityLevel.hidden = TRUE;
    }
}

@end
