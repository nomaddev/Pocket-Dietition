#import "_FoodGroup.h"

@interface FoodGroup : _FoodGroup {}
// Custom logic goes here.
@end
