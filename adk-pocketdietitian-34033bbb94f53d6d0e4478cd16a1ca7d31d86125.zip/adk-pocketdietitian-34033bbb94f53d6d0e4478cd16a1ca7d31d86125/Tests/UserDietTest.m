//
//  UserDietTest.m
//  pocketdietitian
//
//  Created by Rafael Santiago, Jr. on 2/21/12.
//  Copyright (c) 2012 New Frontier Nomads. All rights reserved.
//

#import "UserDietTest.h"

@implementation UserDietTest

-(void) testUserDietCreate{
    
}

@end
